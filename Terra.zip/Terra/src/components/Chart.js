import React, { useLayoutEffect, useState } from "react";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useContext } from "react";
import { CryptoContext } from "./../context/CryptoContext";

function CustomTooltip({ payload, label, active, currency = "usd" }) {
  if (active && payload && payload.length > 0) {
    return (
      <div className="custom-tooltip">
        <p className="label text-sm text-cyan">{`${label} : ${new Intl.NumberFormat(
          "en-IN",
          {
            style: "currency",
            currency: currency,
            minimumFractionDigits: 5,
          }
        ).format(payload[0].value)}`}</p>
      </div>
    );
  }

  return null;
}

const ChartComponent = ({ data, currency, type }) => {
  return (
    <ResponsiveContainer height={"90%"}>
      <LineChart width={400} height={400} data={data}>
        <Line
          type="monotone"
          dataKey={type}
          stroke="#14ffec"
          strokeWidth={"1px"}
        />
        <CartesianGrid stroke="#323232" />
        <XAxis dataKey="date" hide />
        <YAxis dataKey={type} hide domain={["auto", "auto"]} />
        <Tooltip
          content={<CustomTooltip />}
          currency={currency}
          cursor={false}
          wrapperStyle={{ outline: "none" }}
        />
        <Legend />
      </LineChart>
    </ResponsiveContainer>
  );
};

const Chart = ({ id }) => {
  const [chartData, setChartData] = useState();
  let { currency } = useContext(CryptoContext);
  const [type, setType] = useState("prices");
  const [days, setDays] = useState(7);

  useLayoutEffect(() => {
    const getChartData = async (id) => {
      try {
        // const data = await fetch(
        //   `https://api.coingecko.com/api/v3/coins/${id}/market_chart?vs_currency=usd&days=${days}&interval=daily`
        // )
        //   .then((res) =>
        //     res.json()
        //   )
        //   .then((json) => json);
        const data = ({ "prices": [[1728864000000, 62829.533686088886], [1728950400000, 66049.99492708022], [1729036800000, 66962.21994496793], [1729123200000, 67647.54414766871], [1729209600000, 67328.10527002988], [1729296000000, 68465.61920668735], [1729382400000, 68388.87128965274], [1729411586000, 68397.42549520386]], "market_caps": [[1728864000000, 1241241970951.0295], [1728950400000, 1306085613997.8015], [1729036800000, 1323774576161.621], [1729123200000, 1337304399194.887], [1729209600000, 1330387728623.8188], [1729296000000, 1353541799303.4875], [1729382400000, 1351942347611.1997], [1729411586000, 1352275362115.897]], "total_volumes": [[1728864000000, 16784552979.060463], [1728950400000, 46553796134.14602], [1729036800000, 51797932876.82809], [1729123200000, 40640495380.19594], [1729209600000, 34512072357.92087], [1729296000000, 39984956633.228035], [1729382400000, 14110889435.452631], [1729411586000, 13946180163.867163]] })

        // console.log("chart-data", data);

        let convertedData = data[type].map((item) => {
          return {
            date: new Date(item[0]).toLocaleDateString(),
            [type]: item[1],
          };
        });

        // console.log(convertedData);
        setChartData(convertedData);
      } catch (error) {
        console.log(error);
      }
    };

    getChartData(id);
  }, [id, type, days]);

  return (
    <div className="w-full h-[60%]">
      <ChartComponent data={chartData} currency={currency} type={type} />
      <div className="flex">
        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${type === "prices"
            ? "bg-cyan text-cyan"
            : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setType("prices")}
        >
          Price
        </button>
        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${type === "market_caps"
            ? "bg-cyan text-cyan"
            : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setType("market_caps")}
        >
          market caps
        </button>
        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${type === "total_volumes"
            ? "bg-cyan text-cyan"
            : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setType("total_volumes")}
        >
          total volumes
        </button>

        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${days === 7 ? "bg-cyan text-cyan" : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setDays(7)}
        >
          7d
        </button>
        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${days === 14 ? "bg-cyan text-cyan" : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setDays(14)}
        >
          14d
        </button>
        <button
          className={`text-sm py-0.5 px-1.5 ml-2 bg-opacity-25 rounded capitalize ${days === 30 ? "bg-cyan text-cyan" : "bg-gray-200 text-gray-100"
            }`}
          onClick={() => setDays(30)}
        >
          30d
        </button>
      </div>
    </div>
  );
};

export default Chart;
