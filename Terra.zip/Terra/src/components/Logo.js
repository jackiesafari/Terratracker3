import React from "react";
import { Link } from "react-router-dom";
import logoSvg from "../assets/logo.jpg";

const Logo = () => {
  return (
    <div className="flex justify-center items-center mt-10">
      <Link
        to="/"
        className="
          [text-decoration:none] text-lg text-cyan flex items-center pt-1
        "
      >
        <img style={{ height: '150px' }} src={logoSvg} alt="Terra" />
        {/* <span>Terra</span> */}
      </Link>
    </div>
  );
};

export default Logo;
