import React, { useEffect, useState } from "react";
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";
import MarkerClusterer from "@googlemaps/markerclusterer";

const mapContainerStyle = {
    height: "400px",
    width: "100%",
};

const center = {
    lat: -14.0865322,
    lng: -54.505771,
};

const Map = () => {
    const [stores, setStores] = useState([]);
    const [markers, setMarkers] = useState([]);
    const [selectedMarker, setSelectedMarker] = useState(null);
    const [bounds, setBounds] = useState(null);

    // Replace with your JSON data URL
    const mapJsonFile = "https://cdn.rawgit.com/rhcarlosweb/google-maps-markers/7facb603/stores.json";

    useEffect(() => {
        const fetchStores = async () => {
            try {
                const response = await fetch(mapJsonFile);
                const data = await response.json();
                setStores(data);
            } catch (error) {
                console.error("Error fetching stores:", error);
            }
        };

        fetchStores();
    }, []);

    useEffect(() => {
        if (stores.length) {
            const newMarkers = stores.map((store) => {
                const { name, location, type } = store;
                return {
                    position: {
                        lat: location.coordinates.lat,
                        lng: location.coordinates.lng,
                    },
                    title: name,
                    category: [location.country.slug, location.state.slug, location.city.slug, location.district.slug, type.slug],
                    icon: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png" // Custom icon URL
                };
            });
            setMarkers(newMarkers);
        }
    }, [stores]);

    const onMarkerClick = (marker) => {
        setSelectedMarker(marker);
    };

    const onMapLoad = (map) => {
        const newBounds = new window.google.maps.LatLngBounds();
        markers.forEach((marker) => {
            newBounds.extend(marker.position);
        });
        setBounds(newBounds);
        map.fitBounds(newBounds);
    };

    return (
        <LoadScript googleMapsApiKey="AIzaSyCrD3h1pMiSgPM80FsGYshVqXgehVJeSpU">
            <GoogleMap
                mapContainerStyle={mapContainerStyle}
                center={center}
                zoom={4}
                onLoad={onMapLoad}
            >
                {markers.map((marker, index) => (
                    <Marker
                        key={index}
                        position={marker.position}
                        title={marker.title}
                        icon={marker.icon} // Use custom icon
                        onClick={() => onMarkerClick(marker)}
                    />
                ))}

                {selectedMarker && (
                    <InfoWindow
                        position={selectedMarker.position}
                        onCloseClick={() => setSelectedMarker(null)}
                    >
                        <div>
                            <h3>{selectedMarker.title}</h3>
                            <p>
                                <strong>Coordinates:</strong> {selectedMarker.position.lat}, {selectedMarker.position.lng}
                            </p>
                            <button onClick={() => getDirections(selectedMarker.position.lat, selectedMarker.position.lng)}>
                                Get Directions
                            </button>
                        </div>
                    </InfoWindow>
                )}
            </GoogleMap>
        </LoadScript>
    );
};

const getDirections = (lat, lng) => {
    const destination = `${lat},${lng}`;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
    window.open(url, '_blank');
};

export default Map;
