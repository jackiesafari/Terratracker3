/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { Figtree: "Figtree" },
    },

    colors: {
      gray: { 100: "#808080", 200: "#323232", 300: "#292929" },
      white: "#f7f9fd",
      cyan: "#00FCFF",
      red: "#d6436e",
      green: "#26B1F3",
    },
    fontSize: {
      sm: "14px",
      md: "18px",
      lg: "24px",
      xl: "32px",
      base: "16px",
    },
  },
  plugins: [require("tailwind-scrollbar")],
};
